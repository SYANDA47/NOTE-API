from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Home page
    path('login/', views.login_user, name='login_user'),
    path('add-note/', views.add_note, name='add_note'),
    path('download/<int:id>/', views.download_note, name='download_note'),
    path('search-again/', views.search_again, name='search_again'),
    
    # API endpoint
    path('api/notes/', views.get_notes, name='get-notes'),
]
