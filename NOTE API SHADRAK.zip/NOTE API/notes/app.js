const BASE_API = "http://127.0.0.1:8000/api"; // Adjust if hosted elsewhere

let currentUser = null;

// Login Function
async function handleLogin(event) {
  event.preventDefault();
  const name = document.getElementById("name").value;
  const id_number = document.getElementById("id_number").value;

  try {
    const response = await fetch(`${BASE_API}/users/?name=${name}&id_number=${id_number}`);
    const data = await response.json();

    if (data.length > 0) {
      currentUser = data[0]; // Save logged-in user info
      showNotesSection();
      fetchNotes();
    } else {
      alert("Invalid credentials. You are not registered.");
    }
  } catch (error) {
    alert("Login error: " + error.message);
  }
}

// Register Function
async function handleRegister(event) {
  event.preventDefault();
  const name = document.getElementById("name").value;
  const id_number = document.getElementById("id_number").value;

  try {
    const response = await fetch(`${BASE_API}/users/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, id_number }),
    });

    if (response.ok) {
      currentUser = await response.json();
      alert("Registration successful. You are now logged in.");
      showNotesSection();
      fetchNotes();
    } else {
      const data = await response.json();
      alert("Registration failed: " + JSON.stringify(data));
    }
  } catch (error) {
    alert("Registration error: " + error.message);
  }
}

// Show Notes Section
function showNotesSection() {
  document.getElementById("login-section").style.display = "none";
  document.getElementById("notes-section").style.display = "block";
  document.getElementById("notes-section").scrollIntoView({ behavior: "smooth" });
}

// Fetch Notes
async function fetchNotes() {
  try {
    const response = await fetch(`${BASE_API}/notes/`);
    const data = await response.json();
    const notes = data.notes || data;

    const listContainer = document.getElementById("notes-list");
    listContainer.innerHTML = ""; // Clear existing notes

    if (notes.length === 0) {
      document.getElementById("notes-warning").classList.remove("d-none");
      document.getElementById("notes-not-found-btn").classList.remove("d-none");
    } else {
      document.getElementById("notes-success").classList.remove("d-none");
      notes.forEach(note => {
        const noteHTML = `
          <div class="note-item d-flex justify-content-between align-items-start">
            <div>
              <h5>${note.title}</h5>
              <p>${note.content}</p>
              ${note.important ? '<span class="badge bg-danger">Important</span>' : ""}
            </div>
            <form method="get" action="/download/${note.id}">
              <button type="submit" class="btn btn-download btn-sm">Download</button>
            </form>
          </div>`;
        listContainer.innerHTML += noteHTML;
      });
    }
  } catch (error) {
    alert("Failed to fetch notes: " + error.message);
  }
}

// Add Note
document.querySelector(".note-form form").addEventListener("submit", async function (event) {
  event.preventDefault();
  const title = event.target.title.value;
  const content = event.target.desc.value;
  const important = event.target.important.checked;

  try {
    const response = await fetch(`${BASE_API}/notes/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, content, important }),
    });

    if (response.ok) {
      event.target.reset();
      fetchNotes(); // Refresh notes
    } else {
      alert("Failed to add note.");
    }
  } catch (error) {
    alert("Error adding note: " + error.message);
  }
});
