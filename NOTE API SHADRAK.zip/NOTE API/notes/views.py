from django.http import JsonResponse

def get_notes(request):
    data = {
        "notes": [
            {"id": 1, "title": "Note 1", "content": "This is note 1"},
            {"id": 2, "title": "Note 2", "content": "This is note 2"},
        ]
    }
    return JsonResponse(data)
