from django.shortcuts import render
from django.http import JsonResponse
from .models import Note, User
from .serializer import NoteSerializer
from django.views.decorators.csrf import csrf_exempt
import json

def index(request):
    return render(request, 'index.html')

def get_notes(request):
    notes = Note.objects.all()
    serializer = NoteSerializer(notes, many=True)
    return JsonResponse(serializer.data, safe=False)

@csrf_exempt
def register_user(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        name = data.get('name')
        id_number = data.get('id_number')
        if name and id_number:
            user = User.objects.create(name=name, id_number=id_number)
            return JsonResponse({"message": "User registered!"})
    return JsonResponse({"error": "Invalid data"}, status=400)
