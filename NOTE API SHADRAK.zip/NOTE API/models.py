from django.db import models

class UserProfile(models.Model):
    name = models.CharField(max_length=100)
    id_number = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return f"{self.name} ({self.id_number})"

class Note(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name='notes')
    title = models.CharField(max_length=255)
    desc = models.TextField()
    important = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.title} - {self.user.name}"
